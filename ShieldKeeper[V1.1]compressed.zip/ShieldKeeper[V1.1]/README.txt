[  SHIELDKEEPER V1.1  ] 

ShieldKeeper est un gestionnaire de mots de passes simple et minimaliste 
conçu le plus intuitivement possible. 


LE PROGRAMME:
Le programme a été comprimé au maximum et comporte en plus de l'executable et du README.txt 
2 dossiers principaux:

-Logs/: 
Il comportera toutes les sauvegardes importantes et vitales au bon fonctionnement du système
tout est crypté et sécurisé (info utilisateur et MDP heureusement ^^).
et tout de même conseillé de faire un backup du contenu de "Logs/" en lieu sûr au cas ou il arrivait quelque chose aux fichiers (qui vous l'avez compris comporte les sauvegardes des MDP).

-Serrure/:
Dans Serrure sera généré un fichier "cle.key" après le 1er démarrage, une clé unique qui permettra le déchiffrement des données lors du lancement du programme.
CETTE CLE EST VITALE POUR VOS DONNEES, VOUS LA PERDEZ VOUS PERDEZ VOS DONNEES.
Il est conseiller de ranger cette clé dans une clé USB ou un drive (cela offre une double sécurité (clé physique + mot de passe maitre) tant que avant chaque lancement elle soit placée dans le dossier "Serrure/".

!!! RENOMMER OU SUPPRIMER UN FICHIER LOGS OU CLE ENTRAVE AU BON FONCTIONNEMENT DU SYSTEME !!!


QUELQUES INSTRUCTIONS 1er DEMARRAGE:
Au 1er démarrage il vous sera demandé de créer un profil utilisateur (un nom et un MDP maitre)
le MDP maitre est extrêmement important, il sera le seul MDP qu'il vous restera a retenir pour acceder a tout les autres, choisissez le consciencieusement !


PROBLEME TECHNIQUE: 
Si vous rencontrer un problème durant l'utilisation vérifier bien l'intégrité des sauvegardes et la présences de tout les fichiers "Logs/" et de la clé "cle.key" dans "Serrure/". Si il manque un des fichiers il vous faudra remplacer les fichiers par votre backup. Sinon, bon… fallait faire gaffe quoi ^^'.


REINITIALISATION:
Si vous souhaitez formater les données c'est simple, il vous suffit de rentrer dans le dossier "Logs" et supprimer son contenu (PAS LE DOSSIER!). Egalement il faudra supprimer la clé du chiffrement ("cle.key"). A son redémarrage le système régénérera tout se qu'il faut.   


Le but 1er étant de m'améliorer en général le projet est loin d'être parfait il y aura toujours des trucs a modifier/ajouter mais j'éspere avoir fait le maximum pour s'en rapprocher.

Merci,
Hugbloc(GitHub)

